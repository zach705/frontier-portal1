// =====================================================================================
// SERVICE BULLETIN / UNIT DOCS PORTAL — OneDrive Test + XLSX/CSV Import + Admin Helper (Free)
// + Tech Keyword Filter + Demo Mode + Sheet Selector + Replace/Update + Error Report + Polished Demo Skin
// =====================================================================================
// New in this version:
// • Demo Mode: Load sample units, variants, and files with one click (no spreadsheet required).
// • Sheet Selector: Pick which worksheet to import from when uploading .xlsx/.xls.
// • Import Mode: Replace vs Append/Update toggle.
// • Error Report: Download a CSV of skipped/invalid rows after import.
// • Polished Demo Skin: Optional presentation theme toggle (subtle).
// =====================================================================================

import React, { useEffect, useMemo, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle
} from "@/components/ui/dialog";
import {
  Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle
} from "@/components/ui/sheet";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Search, Wrench, AlertTriangle, FileText, Plus, Filter, Shield, Save, X, Upload, Cloud, Database, FileCog, Bot, HelpCircle, Download, Palette
} from "lucide-react";

// =====================================================================================
// TYPES
// =====================================================================================

type Attachment = {
  name: string;
  url: string;
  mime?: string;
  source: "onedrive" | "manual" | "other";
};

type UnitRecord = {
  serial: string;                 // e.g., 160250001 (unique)
  modelFamily?: string;           // e.g., X-Smart (from column B "Mudel")
  modelVariant: string;           // e.g., X-Smart A0017 (from column T "user manual" label)
  manufacturedDate?: string;      // column G
  engineBrand?: string;           // J
  engineType?: string;            // K
  engineSerial?: string;          // L
  alternatorBrand?: string;       // M
  alternatorType?: string;        // N
  alternatorSerial?: string;      // O
  floodlights?: string;           // P (type text, e.g., 4X320W Led)
  controllerType?: string;        // Q (examples: ComAp, Deepsea)
  fleetNumber?: string;           // R
  hydraulicType?: string;         // S
  manualRef?: string;             // optional filename/URL (admin will attach manual separately)
};

type ModelVariantAttachments = {
  modelVariant: string;           // e.g., X-Smart A0017
  modelManual?: Attachment | null;
  componentDocs: Record<string, Attachment[]>; // Engine, Hydraulics, Electrical, Cooling, Controller, Alternator, Floodlights, etc.
};

// =====================================================================================
// CONSTANTS & STORAGE KEYS
// =====================================================================================

const LS_UNITS = "sb_units_index_csv_v1";       // serial → UnitRecord
const LS_VARIANTS = "sb_variant_store_v1";      // modelVariant → attachments
const LS_COPILOT_URL = "sb_admin_copilot_url";  // Copilot Studio web experience URL (optional, later)
const LS_THEME = "sb_demo_theme";               // demo theme toggle

const DEFAULT_COMPONENTS = [
  "Engine",
  "Hydraulics",
  "Electrical",
  "Cooling",
  "Controller",
  "Alternator",
  "Floodlights",
  "Drivetrain",
  "Sensors"
];

// =====================================================================================
// HELPERS
// =====================================================================================

function uid(prefix = "id") { return `${prefix}_${Math.random().toString(36).slice(2, 10)}`; }
function nowIso() { return new Date().toISOString(); }

function readLS<T>(key: string, fallback: T): T {
  try { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) as T : fallback; } catch { return fallback; }
}
function writeLS<T>(key: string, value: T) { localStorage.setItem(key, JSON.stringify(value)); }

function normalizeSerial(input: string): string {
  // Keep digits only; your format is 160 + YY + UUUU → 9 digits (e.g., 160250001)
  const s = (input || "").replace(/\D+/g, "");
  return s;
}

function isLikelyXSmartSerial(serial: string): boolean {
  return /^160\d{6}$/i.test(serial); // 160 + 6 digits
}

// --- Minimal CSV parser supporting quoted fields ---
function parseCSV(text: string): string[][] {
  const rows: string[][] = [];
  let i = 0, field = '', row: string[] = [], inQuotes = false;
  while (i < text.length) {
    const c = text[i];
    if (inQuotes) {
      if (c === '"') {
        if (text[i+1] === '"') { field += '"'; i++; } else { inQuotes = false; }
      } else { field += c; }
    } else {
      if (c === '"') { inQuotes = true; }
      else if (c === ',') { row.push(field.trim()); field = ''; }
      else if (c === '\n' || c === '\r') {
        if (field.length > 0 || row.length > 0) { row.push(field.trim()); rows.push(row); row = []; field = ''; }
        if (c === '\r' && text[i+1] === '\n') i++; // handle CRLF
      } else { field += c; }
    }
    i++;
  }
  if (field.length > 0 || row.length > 0) { row.push(field.trim()); rows.push(row); }
  return rows.filter(r => r.length > 0 && r.some(x => x !== ''));
}

// Map headers to canonical keys
function headerIndexMap(headers: string[]) {
  const map: Record<string, number> = {};
  const getIdx = (aliases: string[]) => headers.findIndex(h => aliases.includes(h.trim().toLowerCase()));
  const alias = (name: string, list: string[]) => { const idx = getIdx(list); if (idx >= 0) map[name] = idx; };

  alias('serial', ['serial number','serial','s/n']);
  alias('modelFamily', ['mudel','model','model family']);
  alias('manufacturedDate', ['date of manufacturing','manufactured','mfg date']);
  // VIN columns intentionally ignored
  alias('engineBrand', ['engine brand']);
  alias('engineType', ['engine type']);
  alias('engineSerial', ['engine serial number']);
  alias('alternatorBrand', ['alternator brand']);
  alias('alternatorType', ['alternator type']);
  alias('alternatorSerial', ['alternator serial number']);
  alias('floodlights', ['floodlights']);
  alias('controllerType', ['controller type']);
  alias('fleetNumber', ['fleet number']);
  alias('hydraulicType', ['hydraulic type']);
  // Column T "user manual" used as the model variant label
  alias('modelVariant', ['user manual','manual','variant']);

  return map;
}

// Utility: build and trigger a client-side CSV download
function downloadCSV(filename: string, rows: string[][]) {
  const csv = rows.map(r => r.map(v => {
    if (v == null) return '';
    const s = String(v);
    return s.includes(',') || s.includes('"') || s.includes('\n') ? '"' + s.replace(/"/g,'""') + '"' : s;
  }).join(',')).join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename; a.style.display='none';
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// =====================================================================================
// MAIN COMPONENT
// =====================================================================================

export default function ServiceBulletinPortal() {
  // Admin / Tech mode
  const [adminMode, setAdminMode] = useState(false);

  // Demo theme skin
  const [demoTheme, setDemoTheme] = useState<boolean>(() => readLS(LS_THEME, false));
  useEffect(() => { writeLS(LS_THEME, demoTheme); }, [demoTheme]);

  // Imported unit index & variant attachments store
  const [unitIndex, setUnitIndex] = useState<Record<string, UnitRecord>>(() => readLS(LS_UNITS, {}));
  const [variantStore, setVariantStore] = useState<Record<string, ModelVariantAttachments>>(() => readLS(LS_VARIANTS, {}));

  // Admin Copilot embed (optional, later)
  const [copilotOpen, setCopilotOpen] = useState(false);
  const [copilotUrl, setCopilotUrl] = useState<string>(() => localStorage.getItem(LS_COPILOT_URL) || "");

  // Admin Helper (FREE, local)
  const [helperOpen, setHelperOpen] = useState(false);
  const [helperQuestion, setHelperQuestion] = useState("");
  const [helperAnswer, setHelperAnswer] = useState<string>("");
  const [helperNotes, setHelperNotes] = useState<string[]>([]);

  // Tech-side serial gate + keyword filter
  const [techSerial, setTechSerial] = useState("");
  const [docFilter, setDocFilter] = useState("");
  const [resolvedUnit, setResolvedUnit] = useState<UnitRecord | null>(null);
  const [resolvedVariant, setResolvedVariant] = useState<ModelVariantAttachments | null>(null);

  // OneDrive picker (stub) — replace with Graph File Picker later
  function fakeOneDrivePicker() {
    return new Promise<Attachment[]>((resolve) => {
      setTimeout(() => {
        resolve([
          { name: "Sample.pdf", url: "https://example.com/sample.pdf", mime: "application/pdf", source: "onedrive" }
        ]);
      }, 400);
    });
  }

  // Save helpers
  function persistUnits(next: Record<string, UnitRecord>) { setUnitIndex(next); writeLS(LS_UNITS, next); }
  function persistVariants(next: Record<string, ModelVariantAttachments>) { setVariantStore(next); writeLS(LS_VARIANTS, next); }

  // ============================== Admin: Import (XLSX/CSV) ===============================
  const [importStats, setImportStats] = useState<{rows:number; uniques:number; duplicates:number; errors:number; examples: UnitRecord[]}>()
  const [importMode, setImportMode] = useState<'replace'|'update'>('update');
  const [xlsxSheets, setXlsxSheets] = useState<string[]>([]);
  const [selectedSheet, setSelectedSheet] = useState<string>("");
  const [pendingXlsx, setPendingXlsx] = useState<File | null>(null);
  const [errorRows, setErrorRows] = useState<string[][]>([]); // for error report download

  async function parseXlsx(file: File, sheetName?: string): Promise<string[][]> {
    const XLSX = await import(/* webpackChunkName: "xlsx" */ 'xlsx');
    const buf = await file.arrayBuffer();
    const wb = XLSX.read(buf, { type: 'array' });
    const names = wb.SheetNames || [];
    if (!sheetName) {
      // If we haven't selected yet, populate list and store file for second step
      setXlsxSheets(names);
      setSelectedSheet(names[0] || "");
    }
    const target = sheetName || names[0];
    const sheet = wb.Sheets[target];
    const json = XLSX.utils.sheet_to_json<string[]>({ ...sheet } as any, { header: 1, raw: false });
    return json as string[][];
  }

  async function readTableFromFile(file: File, sheetName?: string): Promise<string[][]> {
    const name = (file.name || '').toLowerCase();
    if (name.endsWith('.xlsx') || name.endsWith('.xls')) {
      return await parseXlsx(file, sheetName);
    }
    // default to CSV
    const text = await file.text();
    return parseCSV(text);
  }

  function applyImport(rows: string[][]) {
    if (!rows || rows.length < 2) { alert("The file appears empty or is missing a header row."); return; }
    const headers = rows[0].map(h => (h ?? '').toString().trim());
    const idx = headerIndexMap(headers.map(h => h.toLowerCase()));

    const next: Record<string, UnitRecord> = importMode === 'replace' ? {} : { ...unitIndex };
    let addedOrUpdated = 0, dup = 0, err = 0;
    const ex: UnitRecord[] = [];
    const errs: string[][] = [["Row","Reason","SerialRaw"]];

    for (let r = 1; r < rows.length; r++) {
      const rowArr = rows[r] || [];
      const get = (key: string) => {
        const i = (idx as any)[key];
        if (i === undefined || i < 0) return '';
        const val = rowArr[i];
        return (val === undefined || val === null) ? '' : String(val).trim();
      };

      const serialRaw = get('serial');
      const serial = normalizeSerial(serialRaw);
      if (!serial) { err++; errs.push([String(r+1), 'Missing/invalid serial', String(serialRaw)]); continue; }
      // Optional pattern check
      // if (!isLikelyXSmartSerial(serial)) { err++; errs.push([String(r+1), 'Serial not matching 160YYNNNN', String(serialRaw)]); continue; }

      const record: UnitRecord = {
        serial,
        modelFamily: get('modelFamily') || undefined,
        modelVariant: get('modelVariant') || 'Unknown Variant',
        manufacturedDate: get('manufacturedDate') || undefined,
        engineBrand: get('engineBrand') || undefined,
        engineType: get('engineType') || undefined,
        engineSerial: get('engineSerial') || undefined,
        alternatorBrand: get('alternatorBrand') || undefined,
        alternatorType: get('alternatorType') || undefined,
        alternatorSerial: get('alternatorSerial') || undefined,
        floodlights: get('floodlights') || undefined,
        controllerType: get('controllerType') || undefined,
        fleetNumber: get('fleetNumber') || undefined,
        hydraulicType: get('hydraulicType') || undefined,
        manualRef: undefined,
      };

      if (next[serial]) { dup++; }
      next[serial] = record;
      if (ex.length < 3) ex.push(record);
      addedOrUpdated++;
    }

    setErrorRows(errs);
    setImportStats({ rows: rows.length - 1, uniques: addedOrUpdated - dup, duplicates: dup, errors: err, examples: ex });
    persistUnits(next);
  }

  async function handleImport(file: File) {
    const name = (file.name || '').toLowerCase();
    if (name.endsWith('.xlsx') || name.endsWith('.xls')) {
      // First pass to populate sheets list if needed
      setPendingXlsx(file);
      const rows = await readTableFromFile(file); // this will set xlsxSheets + selectedSheet
      // If multiple sheets, wait for user to confirm; otherwise apply immediately
      if ((xlsxSheets?.length || 0) <= 1) {
        applyImport(rows);
      }
      return;
    }
    // CSV
    const rows = await readTableFromFile(file);
    applyImport(rows);
  }

  async function confirmSheetAndImport() {
    if (!pendingXlsx) return;
    const rows = await readTableFromFile(pendingXlsx, selectedSheet);
    applyImport(rows);
    setPendingXlsx(null);
  }

  function downloadErrors() {
    if (!errorRows || errorRows.length <= 1) { alert('No errors to download.'); return; }
    downloadCSV(`import-errors-${Date.now()}.csv`, errorRows);
  }

  // ========================= Admin: Variant Attachments Manager =========================
  const [selectedVariant, setSelectedVariant] = useState<string>("");

  const allVariants = useMemo(() => {
    const set = new Set<string>();
    Object.values(unitIndex).forEach(u => set.add(u.modelVariant));
    return Array.from(set).sort();
  }, [unitIndex]);

  function ensureVariant(v: string) {
    const existing = variantStore[v];
    if (existing) return existing;
    const created: ModelVariantAttachments = { modelVariant: v, modelManual: null, componentDocs: {} };
    DEFAULT_COMPONENTS.forEach(c => created.componentDocs[c] = []);
    const next = { ...variantStore, [v]: created };
    persistVariants(next);
    return created;
  }

  function addManualToVariant(v: string, att: Attachment) {
    const copy = { ...variantStore };
    const target = copy[v] || ensureVariant(v);
    target.modelManual = att;
    copy[v] = target;
    persistVariants(copy);
  }

  function addDocToComponent(v: string, component: string, att: Attachment) {
    const copy = { ...variantStore };
    const target = copy[v] || ensureVariant(v);
    if (!target.componentDocs[component]) target.componentDocs[component] = [];
    target.componentDocs[component] = [...target.componentDocs[component], att];
    copy[v] = target;
    persistVariants(copy);
  }

  function removeDocFromComponent(v: string, component: string, idx: number) {
    const copy = { ...variantStore };
    const target = copy[v]; if (!target) return;
    target.componentDocs[component] = target.componentDocs[component].filter((_, i) => i !== idx);
    copy[v] = target; persistVariants(copy);
  }

  // ============================== Tech: Resolve Serial ==============================
  function resolveBySerial(input: string) {
    const s = normalizeSerial(input);
    if (!s) { setResolvedUnit(null); setResolvedVariant(null); return; }
    const unit = unitIndex[s];
    setResolvedUnit(unit || null);
    if (unit) {
      const variant = ensureVariant(unit.modelVariant);
      setResolvedVariant(variant);
    } else {
      setResolvedVariant(null);
    }
  }

  useEffect(() => { resolveBySerial(techSerial); }, [techSerial]);

  // ============================== Admin Helper (FREE, local) ==============================
  function scrollTo(id: string) {
    try { document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' }); } catch {}
  }

  function getStats() {
    const totalUnits = Object.keys(unitIndex).length;
    const variantSet = new Set<string>();
    Object.values(unitIndex).forEach(u => variantSet.add(u.modelVariant));
    const variants = Array.from(variantSet);
    const missingManual = variants.filter(v => !(variantStore[v]?.modelManual));
    const unknownVariantUnits = Object.values(unitIndex).filter(u => (u.modelVariant || '').toLowerCase() === 'unknown variant').length;
    const missingByComponent: Record<string, number> = {};
    DEFAULT_COMPONENTS.forEach(c => {
      let count = 0; variants.forEach(v => { if (!variantStore[v]?.componentDocs?.[c]?.length) count++; });
      missingByComponent[c] = count;
    });
    return { totalUnits, variants, missingManual, unknownVariantUnits, missingByComponent };
  }

  function runLocalHelper(question: string) {
    const q = (question || '').toLowerCase();
    const stats = getStats();
    const notes: string[] = [];

    function listTop(arr: string[], n = 10) { return arr.slice(0, n).map(v => `• ${v}`); }

    if (!q.trim()) {
      setHelperAnswer(
        `Try one of these:\n- "Why is my serial not found?"\n- "Which variants are missing manuals?"\n- "Show variants missing Controller docs"\n- "How do I import the XLSX?"\n- "How do I attach a manual?"`
      );
      setHelperNotes([`Units: ${stats.totalUnits}`, `Variants: ${stats.variants.length}`, `Unknown-variant units: ${stats.unknownVariantUnits}`]);
      return;
    }

    if (q.includes('serial') && (q.includes('not found') || q.includes('no data'))) {
      setHelperAnswer(
        `If a serial isn't found:\n1) Import the latest .xlsx in Admin → Data Import.\n2) Confirm the **Serial number** column exists and values look like 160YYNNNN (digits only).\n3) If your data is on a different worksheet, use the **Sheet** selector.\n4) Re-try search with digits only (e.g., 160250001).`
      );
      setHelperNotes([`Unknown-variant units: ${stats.unknownVariantUnits}`]);
      return;
    }

    if (q.includes('import') || q.includes('xlsx') || q.includes('csv')) {
      setHelperAnswer(
        `Import checklist:\n- Preferred format: **.xlsx** (Admin → Data Import).\n- Required headers: **Serial number**, **user manual** (model variant label).\n- Optional: Mudel, Date of manufacturing, Engine/Alternator, Floodlights, Controller type, Fleet number, Hydraulic type.\n- Choose **Replace** to clear all previous data or **Update** to upsert by serial.\n- If your data isn't on the first worksheet, pick the correct **Sheet** and click **Import Selected Sheet**.`
      );
      setHelperNotes([`Units: ${stats.totalUnits}`, `Variants detected: ${stats.variants.length}`]);
      return;
    }

    if (q.includes('missing manual') || q.includes('no manual')) {
      const list = listTop(stats.missingManual, 10);
      setHelperAnswer(
        list.length
          ? `Top variants missing manuals (first 10):\n${list.join('\n')}\n\nClick a quick action to jump to attachments.`
          : `Great — all detected variants have a manual attached.`
      );
      setHelperNotes([`Total variants: ${stats.variants.length}`, `Missing manuals: ${stats.missingManual.length}`]);
      return;
    }

    for (const comp of DEFAULT_COMPONENTS) {
      if (q.includes(comp.toLowerCase())) {
        const missing = stats.variants.filter(v => !(variantStore[v]?.componentDocs?.[comp]?.length));
        const list = listTop(missing, 10);
        setHelperAnswer(
          missing.length
            ? `Variants missing **${comp}** docs (first 10):\n${list.join('\n')}\n\nAdd files in Admin → Model Variant Attachments.`
            : `All variants appear to have **${comp}** docs attached (based on current data).`
        );
        setHelperNotes([`Missing ${comp}: ${missing.length}`, `Variants total: ${stats.variants.length}`]);
        return;
      }
    }

    if (q.includes('attach') || q.includes('manual')) {
      setHelperAnswer(
        `Attach files steps:\n1) Admin → Model Variant Attachments.\n2) Choose a variant (e.g., X‑Smart A0017).\n3) **Set/Replace Model Manual** to attach the PDF.\n4) For components (Engine, Controller, etc.), click **Add File** under each category.`
      );
      setHelperNotes([]);
      return;
    }

    setHelperAnswer(`I didn’t recognize that yet. Try mentioning a component (e.g., "Controller"), "missing manual", or "import".`);
    setHelperNotes([]);
  }

  // ============================== PDF Viewer ==============================
  function PdfViewer({ url }: { url: string }) {
    if (!url) return null;
    return (
      <div className={`w-full h-[70vh] border rounded-md overflow-hidden ${demoTheme ? 'bg-gradient-to-br from-white to-slate-50' : 'bg-white'}`}>
        <iframe src={url} className="w-full h-full" title="PDF Viewer" />
      </div>
    );
  }

  // ============================== DEMO DATA LOADER ==============================
  function loadDemoData() {
    // Minimal but realistic demo data: 6 units across 2 variants
    const units: Record<string, UnitRecord> = {
      '160250001': { serial: '160250001', modelFamily: 'X-Smart', modelVariant: 'X-Smart A0017', manufacturedDate: '2025-01-12', controllerType: 'ComAp', hydraulicType: 'HX-Std', floodlights: '4x320W LED', engineBrand: 'Kubota', engineType: 'D902' },
      '160250002': { serial: '160250002', modelFamily: 'X-Smart', modelVariant: 'X-Smart A0017', manufacturedDate: '2025-01-13', controllerType: 'ComAp', hydraulicType: 'HX-Std', floodlights: '4x320W LED', engineBrand: 'Kubota', engineType: 'D902' },
      '160250101': { serial: '160250101', modelFamily: 'X-Smart', modelVariant: 'X-Smart A0019', manufacturedDate: '2025-02-02', controllerType: 'Deepsea', hydraulicType: 'HX-Pro', floodlights: '4x320W LED', engineBrand: 'Kubota', engineType: 'D902' },
      '160250102': { serial: '160250102', modelFamily: 'X-Smart', modelVariant: 'X-Smart A0019', manufacturedDate: '2025-02-03', controllerType: 'Deepsea', hydraulicType: 'HX-Pro', floodlights: '4x320W LED' },
      '160250201': { serial: '160250201', modelFamily: 'X-Smart', modelVariant: 'X-Smart A0017', manufacturedDate: '2025-03-10', controllerType: 'ComAp' },
      '160250202': { serial: '160250202', modelFamily: 'X-Smart', modelVariant: 'X-Smart A0019', manufacturedDate: '2025-03-11', controllerType: 'Deepsea' },
    };

    const variants: Record<string, ModelVariantAttachments> = {
      'X-Smart A0017': {
        modelVariant: 'X-Smart A0017',
        modelManual: { name: 'XSmart_A0017_Manual.pdf', url: 'https://example.com/manuals/a0017.pdf', mime: 'application/pdf', source: 'manual' },
        componentDocs: {
          Engine: [ { name: 'Engine_2025_Spec.pdf', url: 'https://example.com/engine-2025.pdf', mime: 'application/pdf', source: 'manual' } ],
          Controller: [ { name: 'ComAp_Setup_Guide.pdf', url: 'https://example.com/comap-setup.pdf', mime: 'application/pdf', source: 'manual' } ],
          Hydraulics: [], Electrical: [], Cooling: [], Alternator: [], Floodlights: [], Drivetrain: [], Sensors: []
        }
      },
      'X-Smart A0019': {
        modelVariant: 'X-Smart A0019',
        modelManual: { name: 'XSmart_A0019_Manual.pdf', url: 'https://example.com/manuals/a0019.pdf', mime: 'application/pdf', source: 'manual' },
        componentDocs: {
          Engine: [ { name: 'Engine_2025_Spec.pdf', url: 'https://example.com/engine-2025.pdf', mime: 'application/pdf', source: 'manual' } ],
          Controller: [ { name: 'Deepsea_Config.pdf', url: 'https://example.com/deepsea-config.pdf', mime: 'application/pdf', source: 'manual' } ],
          Hydraulics: [ { name: 'Hydraulic_Service_v3.pdf', url: 'https://example.com/hydraulic-v3.pdf', mime: 'application/pdf', source: 'manual' } ],
          Electrical: [], Cooling: [], Alternator: [], Floodlights: [], Drivetrain: [], Sensors: []
        }
      }
    } as any;

    persistUnits(units);
    persistVariants(variants);
  }

  // ============================== RENDER: Tech View ==============================
  function TechPanel() {
    const unit = resolvedUnit;
    const variant = resolvedVariant;

    // Prepare a filtered view of component docs based on keyword
    const kw = docFilter.trim().toLowerCase();
    const manualMatches = kw
      ? !!variant?.modelManual && (
          variant.modelManual.name.toLowerCase().includes(kw) ||
          variant.modelManual.url.toLowerCase().includes(kw)
        )
      : true;

    const filteredComponentDocs: Record<string, Attachment[]> = {} as any;
    Object.entries(variant?.componentDocs || {}).forEach(([component, docs]) => {
      const list = (docs || []).filter(a =>
        !kw || a.name.toLowerCase().includes(kw) || a.url.toLowerCase().includes(kw)
      );
      if (list.length > 0) filteredComponentDocs[component] = list;
    });

    const anyDocs = variant && (
      (manualMatches && !!variant.modelManual) ||
      Object.keys(filteredComponentDocs).length > 0
    );

    return (
      <Card className={demoTheme ? 'border-slate-200 shadow-sm' : ''}>
        <CardContent className="p-4 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3 items-end">
            <div className="md:col-span-2">
              <Label>Enter Serial Number</Label>
              <div className="relative mt-1">
                <Search className="h-4 w-4 absolute left-2 top-2.5 text-slate-400" />
                <Input
                  className="pl-8"
                  placeholder="e.g., 160250001"
                  value={techSerial}
                  onChange={(e) => setTechSerial(e.target.value)}
                />
              </div>
              <p className="text-xs text-slate-500 mt-1">Format: 160 + YY + UUUU (digits only). We’ll only show documents for that exact unit.</p>
            </div>

            {/* Keyword filter shown after a unit is resolved */}
            <div className="md:col-span-2">
              <Label>Filter files by keyword (after serial lookup)</Label>
              <Input
                placeholder="e.g., engine, controller, wiring, manual…"
                value={docFilter}
                onChange={(e) => setDocFilter(e.target.value)}
              />
              <p className="text-xs text-slate-500 mt-1">Filters the model manual and component documents by filename/link text.</p>
            </div>
          </div>

          {!unit && techSerial && (
            <div className="border rounded-lg p-6 text-center text-slate-500">
              <AlertTriangle className="h-5 w-5 mx-auto mb-2" />
              No data found for serial <strong>{normalizeSerial(techSerial)}</strong>. Please verify the number or contact support.
            </div>
          )}

          {unit && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold">{unit.modelVariant}</h3>
                  <p className="text-sm text-slate-600">Serial: {unit.serial}{unit.modelFamily ? ` • Family: ${unit.modelFamily}` : ''}</p>
                  <div className="flex flex-wrap gap-2 mt-2 text-xs text-slate-600">
                    {unit.manufacturedDate && <span><strong>Mfg:</strong> {unit.manufacturedDate}</span>}
                    {unit.controllerType && <span><strong>Controller:</strong> {unit.controllerType}</span>}
                    {unit.hydraulicType && <span><strong>Hydraulics:</strong> {unit.hydraulicType}</span>}
                    {unit.floodlights && <span><strong>Floodlights:</strong> {unit.floodlights}</span>}
                    {(unit.engineBrand || unit.engineType) && <span><strong>Engine:</strong> {[unit.engineBrand, unit.engineType].filter(Boolean).join(' ')}</span>}
                    {(unit.alternatorBrand || unit.alternatorType) && <span><strong>Alternator:</strong> {[unit.alternatorBrand, unit.alternatorType].filter(Boolean).join(' ')}</span>}
                  </div>
                </div>
              </div>

              {/* Documents for this model variant */}
              <Tabs defaultValue="docs" className="mt-2">
                <TabsList>
                  <TabsTrigger value="docs">Documents</TabsTrigger>
                  <TabsTrigger value="details">Unit Details</TabsTrigger>
                </TabsList>

                <TabsContent value="docs" className="space-y-4">
                  {/* Model Manual (if present & keyword matches) */}
                  {variant?.modelManual && manualMatches ? (
                    <div className="space-y-2">
                      <h4 className="font-semibold">Model Manual</h4>
                      {variant.modelManual.mime?.includes('pdf') || variant.modelManual.url.toLowerCase().endsWith('.pdf') ? (
                        <PdfViewer url={variant.modelManual.url} />
                      ) : (
                        <a className="text-blue-600 text-sm hover:underline" target="_blank" rel="noreferrer" href={variant.modelManual.url}>{variant.modelManual.name}</a>
                      )}
                    </div>
                  ) : variant?.modelManual && kw ? (
                    <p className="text-xs text-slate-500">Model manual hidden by filter.</p>
                  ) : (
                    <p className="text-sm text-slate-500">No model manual attached for {unit.modelVariant} yet.</p>
                  )}

                  {/* Component documents — filtered by keyword and basic relevancy */}
                  <div className="space-y-4">
                    {Object.entries(filteredComponentDocs).map(([component, docs]) => {
                      if (!docs || docs.length === 0) return null;
                      const relevant = (
                        (component === 'Engine' && (unit.engineBrand || unit.engineType)) ||
                        (component === 'Hydraulics' && unit.hydraulicType) ||
                        (component === 'Controller' && unit.controllerType) ||
                        (component === 'Alternator' && (unit.alternatorBrand || unit.alternatorType)) ||
                        (component === 'Floodlights' && unit.floodlights) ||
                        ['Electrical','Cooling','Drivetrain','Sensors'].includes(component)
                      );
                      if (!relevant) return null;
                      return (
                        <div key={component} className="space-y-2">
                          <h4 className="font-semibold">{component}</h4>
                          <ul className="space-y-2">
                            {docs.map((a, i) => (
                              <li key={i} className="flex items-center justify-between p-2 bg-slate-50 rounded-md">
                                <div className="flex items-center gap-2">
                                  <FileText className="h-4 w-4 text-slate-500" />
                                  <span className="text-sm">{a.name}</span>
                                </div>
                                <a href={a.url} className="text-xs text-blue-600 hover:underline" target="_blank" rel="noreferrer">Open</a>
                              </li>
                            ))}
                          </ul>
                        </div>
                      );
                    })}
                    {unit && !anyDocs && (
                      <p className="text-sm text-slate-500">No documents match the current keyword filter.</p>
                    )}
                  </div>
                </TabsContent>

                <TabsContent value="details" className="text-sm text-slate-700 space-y-2">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-2">
                    <div><strong>Serial:</strong> {unit.serial}</div>
                    {unit.modelFamily && <div><strong>Family:</strong> {unit.modelFamily}</div>}
                    <div><strong>Variant:</strong> {unit.modelVariant}</div>
                    {unit.manufacturedDate && <div><strong>Mfg Date:</strong> {unit.manufacturedDate}</div>}
                    {(unit.engineBrand || unit.engineType) && <div><strong>Engine:</strong> {[unit.engineBrand, unit.engineType].filter(Boolean).join(' • ')}</div>}
                    {unit.engineSerial && <div><strong>Engine S/N:</strong> {unit.engineSerial}</div>}
                    {(unit.alternatorBrand || unit.alternatorType) && <div><strong>Alternator:</strong> {[unit.alternatorBrand, unit.alternatorType].filter(Boolean).join(' • ')}</div>}
                    {unit.alternatorSerial && <div><strong>Alternator S/N:</strong> {unit.alternatorSerial}</div>}
                    {unit.controllerType && <div><strong>Controller:</strong> {unit.controllerType}</div>}
                    {unit.hydraulicType && <div><strong>Hydraulics:</strong> {unit.hydraulicType}</div>}
                    {unit.floodlights && <div><strong>Floodlights:</strong> {unit.floodlights}</div>}
                    {unit.fleetNumber && <div><strong>Fleet #:</strong> {unit.fleetNumber}</div>}
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          )}
        </CardContent>
      </Card>
    );
  }

  // ============================== RENDER: Admin Panels ==============================

  function AdminPanels() {
    const [file, setFile] = useState<File | null>(null);
    const [componentInput, setComponentInput] = useState<string>(DEFAULT_COMPONENTS.join(", "));

    useEffect(() => {
      // ensure default components initialize for existing variants
      Object.keys(variantStore).forEach(v => {
        const vs = variantStore[v];
        DEFAULT_COMPONENTS.forEach(c => {
          if (!vs.componentDocs[c]) vs.componentDocs[c] = [];
        });
      });
      persistVariants({ ...variantStore });
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    function saveComponentTemplate() {
      const parts = componentInput.split(',').map(s => s.trim()).filter(Boolean);
      const next = { ...variantStore };
      Object.keys(next).forEach(v => {
        parts.forEach(p => { if (!next[v].componentDocs[p]) next[v].componentDocs[p] = []; });
      });
      setVariantStore(next); persistVariants(next);
    }

    function saveCopilotUrl() {
      localStorage.setItem(LS_COPILOT_URL, copilotUrl);
    }

    const stats = getStats();

    return (
      <div className="space-y-6">
        {/* Header: Theme + Demo data */}
        <Card>
          <CardContent className="p-4 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-sm text-slate-600">
              <Palette className="h-4 w-4" /> Demo theme
              <Switch checked={demoTheme} onCheckedChange={setDemoTheme} />
            </div>
            <div className="flex items-center gap-2">
              <Button variant="secondary" onClick={loadDemoData}><Plus className="h-4 w-4 mr-1"/> Load Sample Data (Demo)</Button>
            </div>
          </CardContent>
        </Card>

        {/* Admin Helper (FREE) */}
        <Card>
          <CardContent className="p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <HelpCircle className="h-5 w-5 text-slate-600" />
                <h3 className="font-semibold">Admin Helper (free, local)</h3>
              </div>
              <div className="flex items-center gap-2">
                <Button variant="secondary" onClick={() => setHelperOpen(true)}>Open Helper</Button>
              </div>
            </div>
            <div className="text-xs text-slate-600">Quick snapshot — Units: <strong>{stats.totalUnits}</strong> • Variants: <strong>{stats.variants.length}</strong> • Unknown-variant units: <strong>{stats.unknownVariantUnits}</strong></div>
            <div className="flex flex-wrap gap-2 text-[11px] text-slate-600">
              {Object.entries(stats.missingByComponent).map(([c, n]) => (
                <span key={c} className="px-2 py-0.5 bg-slate-50 border rounded">Missing {c}: <strong>{n}</strong></span>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* XLSX/CSV Import */}
        <Card id="import-section">
          <CardContent className="p-4 space-y-4">
            <div className="flex items-center gap-2">
              <Database className="h-5 w-5 text-slate-600" />
              <h3 className="font-semibold">Data Import (XLSX/CSV) — Serial → Model Variant</h3>
            </div>
            <p className="text-sm text-slate-600">Upload your spreadsheet as <strong>.xlsx</strong> (preferred) or <strong>.csv</strong>. Required columns: <strong>Serial number</strong>, <strong>user manual</strong> (model variant). Optional: Mudel (family), Date of manufacturing, Engine/Alternator details, Floodlights, Controller type, Fleet number, Hydraulic type. VIN columns are ignored.</p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 items-end">
              <div className="md:col-span-2 flex items-center gap-2">
                <input type="file" accept=".xlsx,.xls,.csv,text/csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel" onChange={(e) => setFile(e.target.files?.[0] || null)} />
                <Select value={importMode} onValueChange={(v:any)=>setImportMode(v)}>
                  <SelectTrigger className="w-[160px]"><SelectValue placeholder="Mode"/></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="update">Update (upsert)</SelectItem>
                    <SelectItem value="replace">Replace all</SelectItem>
                  </SelectContent>
                </Select>
                <Button disabled={!file} onClick={() => file && handleImport(file)}>Import</Button>
              </div>
              {/* Sheet selector appears only for XLSX with multiple sheets */}
              {pendingXlsx && xlsxSheets.length > 0 && (
                <div className="flex items-center gap-2">
                  <Label>Sheet</Label>
                  <Select value={selectedSheet} onValueChange={(v)=>setSelectedSheet(v)}>
                    <SelectTrigger className="w-[220px]"><SelectValue placeholder="Select sheet"/></SelectTrigger>
                    <SelectContent>
                      {xlsxSheets.map(n => <SelectItem key={n} value={n}>{n}</SelectItem>)}
                    </SelectContent>
                  </Select>
                  <Button variant="secondary" onClick={confirmSheetAndImport}>Import Selected Sheet</Button>
                </div>
              )}
            </div>

            {importStats && (
              <div className="text-xs text-slate-600 space-y-1">
                <div>Rows: {importStats.rows} • Unique added/updated: {importStats.uniques} • Duplicates: {importStats.duplicates} • Errors: {importStats.errors}</div>
                <div className="flex items-center gap-2">
                  <div className="text-slate-500">Examples:</div>
                  <Button size="sm" variant="outline" onClick={downloadErrors}><Download className="h-3 w-3 mr-1"/> Error report (CSV)</Button>
                </div>
                <pre className="bg-slate-50 p-2 rounded text-[11px] overflow-x-auto">{JSON.stringify(importStats.examples, null, 2)}</pre>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Variant Attachments Manager */}
        <Card id="attachments-section" className={demoTheme ? 'border-slate-200 shadow-sm' : ''}>
          <CardContent className="p-4 space-y-4">
            <div className="flex items-center gap-2">
              <FileCog className="h-5 w-5 text-slate-600" />
              <h3 className="font-semibold">Model Variant Attachments</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <Label>Choose Variant</Label>
                <Select value={selectedVariant} onValueChange={(v) => { setSelectedVariant(v); ensureVariant(v); }}>
                  <SelectTrigger><SelectValue placeholder="Select model variant (e.g., X-Smart A0017)" /></SelectTrigger>
                  <SelectContent>
                    {allVariants.length === 0 && <div className="p-2 text-sm text-slate-500">No variants yet — import file or load demo first.</div>}
                    {allVariants.map(v => <SelectItem key={v} value={v}>{v}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Component Template (comma-separated)</Label>
                <Input value={componentInput} onChange={(e) => setComponentInput(e.target.value)} />
                <div className="flex gap-2 mt-2">
                  <Button variant="outline" size="sm" onClick={saveComponentTemplate}>Apply to All Variants</Button>
                </div>
              </div>
            </div>

            {selectedVariant && (
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <strong className="text-sm">{selectedVariant}</strong>
                  <Button size="sm" variant="secondary" onClick={async () => {
                    const picked = await fakeOneDrivePicker();
                    if (picked && picked[0]) addManualToVariant(selectedVariant, picked[0]);
                  }}><Cloud className="h-4 w-4 mr-1"/> Set/Replace Model Manual</Button>
                </div>
                <div>
                  <Label className="text-sm">Components</Label>
                  <div className="space-y-3 mt-2">
                    {Object.entries(ensureVariant(selectedVariant).componentDocs).map(([component, docs]) => (
                      <div key={component} className="border rounded p-3">
                        <div className="flex items-center justify-between">
                          <h4 className="font-medium">{component}</h4>
                          <Button size="sm" variant="outline" onClick={async () => {
                            const picked = await fakeOneDrivePicker();
                            picked.forEach(p => addDocToComponent(selectedVariant, component, p));
                          }}>
                            <Upload className="h-4 w-4 mr-1"/> Add File
                          </Button>
                        </div>
                        {(!docs || docs.length === 0) && (
                          <p className="text-xs text-slate-500 mt-2">No files attached.</p>
                        )}
                        <ul className="mt-2 space-y-1">
                          {docs?.map((a, i) => (
                            <li key={i} className="text-sm flex items-center justify-between bg-slate-50 px-2 py-1 rounded">
                              <span className="truncate max-w-[70%]" title={a.name}>{a.name}</span>
                              <Button size="xs" variant="ghost" onClick={() => removeDocFromComponent(selectedVariant, component, i)}><X className="h-3 w-3"/></Button>
                            </li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Admin Copilot dialog (optional, later) */}
        <Dialog open={copilotOpen} onOpenChange={setCopilotOpen}>
          <DialogContent className="max-w-4xl h-[80vh] p-0 overflow-hidden">
            <DialogHeader className="px-4 pt-4 pb-2">
              <DialogTitle className="flex items-center gap-2"><Bot className="h-5 w-5"/> Admin Copilot</DialogTitle>
              <DialogDescription className="px-1">Optional: paste your Copilot Studio web app URL when you get access. (The free local Helper above already works.)</DialogDescription>
            </DialogHeader>
            {copilotUrl ? (
              <iframe src={copilotUrl} className="w-full h-[calc(80vh-88px)] border-t" title="Admin Copilot" />
            ) : (
              <div className="p-6 text-sm text-slate-600">No Copilot URL set yet.</div>
            )}
          </DialogContent>
        </Dialog>

        {/* Admin Helper dialog (free, local) */}
        <Dialog open={helperOpen} onOpenChange={setHelperOpen}>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2"><HelpCircle className="h-5 w-5"/> Admin Helper (free)</DialogTitle>
              <DialogDescription>Ask how to import, find missing docs, or troubleshoot. No external services required.</DialogDescription>
            </DialogHeader>

            <div className="space-y-3">
              <div>
                <Label>Your question</Label>
                <textarea
                  rows={3}
                  className="mt-1 w-full border rounded-md p-2 text-sm"
                  placeholder="e.g., Which variants are missing Controller docs?"
                  value={helperQuestion}
                  onChange={(e) => setHelperQuestion(e.target.value)}
                />
              </div>
              <div className="flex gap-2 flex-wrap">
                <Button size="sm" onClick={() => runLocalHelper(helperQuestion)}>Ask</Button>
                <Button size="sm" variant="outline" onClick={() => { setHelperQuestion(""); setHelperAnswer(""); setHelperNotes([]); }}>Clear</Button>
                <Button size="sm" variant="ghost" onClick={() => { setHelperQuestion('Which variants are missing manuals?'); runLocalHelper('Which variants are missing manuals?'); }}>Missing manuals</Button>
                <Button size="sm" variant="ghost" onClick={() => { setHelperQuestion('Show variants missing Controller docs'); runLocalHelper('Show variants missing Controller docs'); }}>Missing Controller</Button>
                <Button size="sm" variant="ghost" onClick={() => { setHelperQuestion('How do I import the XLSX?'); runLocalHelper('How do I import the XLSX?'); }}>How to import</Button>
                <Button size="sm" variant="ghost" onClick={() => { setHelperQuestion('Why is my serial not found?'); runLocalHelper('Why is my serial not found?'); }}>Serial not found</Button>
              </div>

              {helperAnswer && (
                <div className="bg-slate-50 border rounded-md p-3 text-sm whitespace-pre-wrap">{helperAnswer}</div>
              )}
              {helperNotes.length > 0 && (
                <ul className="text-xs text-slate-600 list-disc pl-5 space-y-1">
                  {helperNotes.map((n, i) => <li key={i}>{n}</li>)}
                </ul>
              )}

              <div className="flex flex-wrap gap-2 text-xs">
                <Button size="sm" variant="outline" onClick={() => scrollTo('import-section')}>Go to Import</Button>
                <Button size="sm" variant="outline" onClick={() => scrollTo('attachments-section')}>Go to Attachments</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    );
  }

  // =====================================================================================
  // MAIN RENDER
  // =====================================================================================

  return (
    <div className={`min-h-screen ${demoTheme ? 'bg-slate-50' : 'bg-white'}`}>
      <header className={`border-b p-4 flex justify-between items-center sticky top-0 z-20 ${demoTheme ? 'bg-white/90 backdrop-blur supports-[backdrop-filter]:bg-white/60' : 'bg-white'}`}>
        <div className="flex items-center gap-2">
          <Wrench className="h-6 w-6 text-slate-700" />
          <div>
            <h1 className="text-xl font-semibold">Service Bulletin / Unit Docs Portal</h1>
            <p className="text-xs text-slate-600">OneDrive test • Admin XLSX/CSV import • Technician serial-first lookup • Admin Helper (free)</p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-sm text-slate-600">
            <Shield className="h-4 w-4" /> Admin Mode
            <Switch checked={adminMode} onCheckedChange={setAdminMode} />
          </div>
          {adminMode && (
            <>
              <Button variant="outline" size="sm" onClick={() => setHelperOpen(true)}><HelpCircle className="h-4 w-4 mr-1"/> Help (free)</Button>
            </>
          )}
        </div>
      </header>

      <main className="max-w-6xl mx-auto p-4 space-y-6">
        {!adminMode ? (
          <TechPanel />
        ) : (
          <AdminPanels />
        )}
      </main>
    </div>
  );
}
