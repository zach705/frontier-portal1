
import * as React from "react";
export function Sheet({ children }: { children: React.ReactNode }) { return <div>{children}</div>; }
export function SheetContent({ children }: { children: React.ReactNode }) { return <div className="fixed inset-y-0 right-0 w-96 bg-white border-l p-4">{children}</div>; }
export function SheetHeader({ children }: { children: React.ReactNode }) { return <div className="mb-2">{children}</div>; }
export function SheetTitle({ children }: { children: React.ReactNode }) { return <h3 className="text-lg font-medium">{children}</h3>; }
export function SheetDescription({ children }: { children: React.ReactNode }) { return <p className="text-sm text-slate-600">{children}</p>; }
