
import * as React from "react";

type SelectCtx = { value?: string; setValue: (v: string) => void; open: boolean; setOpen: (v: boolean) => void; };
const Ctx = React.createContext<SelectCtx | null>(null);

export function Select({ value, onValueChange, children }: { value?: string; onValueChange: (v: string) => void; children: React.ReactNode; }) {
  const [curr, setCurr] = React.useState(value || "");
  const [open, setOpen] = React.useState(false);
  React.useEffect(() => { if (value !== undefined) setCurr(value); }, [value]);
  const setValue = (v: string) => { setCurr(v); onValueChange(v); setOpen(false); };
  return <Ctx.Provider value={{ value: curr, setValue, open, setOpen }}>{children}</Ctx.Provider>;
}

export function SelectTrigger({ children, className }: { children: React.ReactNode; className?: string; }) {
  const ctx = React.useContext(Ctx)!;
  return (
    <button onClick={() => ctx.setOpen(!ctx.open)} className={`h-9 w-full rounded-md border px-3 text-left text-sm ${className || ""}`}>
      {children}
    </button>
  );
}

export function SelectValue({ placeholder }: { placeholder?: string }) {
  const ctx = React.useContext(Ctx)!;
  return <span className="text-sm">{ctx.value || placeholder || "Select"}</span>;
}

export function SelectContent({ children }: { children: React.ReactNode }) {
  const ctx = React.useContext(Ctx)!;
  if (!ctx.open) return null;
  return <div className="mt-1 rounded-md border bg-white shadow">{children}</div>;
}

export function SelectItem({ value, children }: { value: string; children: React.ReactNode }) {
  const ctx = React.useContext(Ctx)!;
  return (
    <div onClick={() => ctx.setValue(value)} className="px-3 py-2 text-sm hover:bg-slate-100 cursor-pointer">
      {children}
    </div>
  );
}
