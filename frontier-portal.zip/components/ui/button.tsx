
import * as React from "react";
import clsx from "clsx";

type Variant = "default" | "outline" | "secondary" | "ghost";
type Size = "default" | "sm" | "xs";

export function Button({ className, variant = "default", size = "default", ...props }: React.ComponentProps<"button"> & { variant?: Variant; size?: Size }) {
  const base = "inline-flex items-center justify-center rounded-md font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-slate-400 disabled:opacity-50 disabled:pointer-events-none";
  const variants: Record<Variant, string> = {
    default: "bg-slate-900 text-white hover:bg-slate-800",
    outline: "border border-slate-300 hover:bg-slate-50",
    secondary: "bg-slate-100 hover:bg-slate-200",
    ghost: "hover:bg-slate-100"
  };
  const sizes: Record<Size, string> = {
    default: "h-9 px-3 text-sm",
    sm: "h-8 px-2 text-sm",
    xs: "h-7 px-2 text-xs"
  };
  return <button className={clsx(base, variants[variant], sizes[size], className)} {...props} />;
}
