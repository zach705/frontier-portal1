
import * as React from "react";
import clsx from "clsx";

export function Dialog({ open, onOpenChange, children }: { open: boolean; onOpenChange: (v: boolean) => void; children: React.ReactNode; }) {
  React.useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onOpenChange(false);
    if (open) document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, onOpenChange]);
  return open ? <div className="fixed inset-0 z-50">{children}</div> : null;
}

export function DialogContent({ className, children }: React.ComponentProps<"div">) {
  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center p-4">
      <div className={clsx("w-full max-w-2xl rounded-md bg-white shadow-lg", className)}>{children}</div>
    </div>
  );
}

export function DialogHeader({ children }: React.ComponentProps<"div">) { return <div className="px-4 pt-4 pb-2 border-b">{children}</div>; }
export function DialogTitle({ className, ...props }: React.ComponentProps<"h2">) { return <h2 className={`text-lg font-semibold ${className || ""}`} {...props} />; }
export function DialogDescription({ className, ...props }: React.ComponentProps<"p">) { return <p className={`text-sm text-slate-600 ${className || ""}`} {...props} />; }
