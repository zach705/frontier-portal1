
import * as React from "react";
import clsx from "clsx";

export function Card({ className, ...props }: React.ComponentProps<"div">) {
  return <div className={clsx("border rounded-lg bg-white", className)} {...props} />;
}

export function CardContent({ className, ...props }: React.ComponentProps<"div">) {
  return <div className={clsx("p-4", className)} {...props} />;
}
