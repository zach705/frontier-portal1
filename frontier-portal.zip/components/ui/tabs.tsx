
import * as React from "react";

type TabsContextType = { value: string; setValue: (v: string) => void; };
const TabsContext = React.createContext<TabsContextType | null>(null);

export function Tabs({ defaultValue, className, children }: { defaultValue: string; className?: string; children: React.ReactNode; }) {
  const [value, setValue] = React.useState(defaultValue);
  return <div className={className}><TabsContext.Provider value={{ value, setValue }}>{children}</TabsContext.Provider></div>;
}

export function TabsList({ children }: { children: React.ReactNode }) {
  return <div className="inline-flex rounded-md border bg-slate-50 p-1">{children}</div>;
}

export function TabsTrigger({ value, children }: { value: string; children: React.ReactNode }) {
  const ctx = React.useContext(TabsContext)!;
  const active = ctx.value === value;
  return (
    <button onClick={() => ctx.setValue(value)} className={`px-3 py-1 text-sm rounded ${active ? "bg-white border" : "text-slate-600 hover:text-slate-900"}`}>
      {children}
    </button>
  );
}

export function TabsContent({ value, className, children }: { value: string; className?: string; children: React.ReactNode }) {
  const ctx = React.useContext(TabsContext)!;
  if (ctx.value !== value) return null;
  return <div className={className}>{children}</div>;
}
