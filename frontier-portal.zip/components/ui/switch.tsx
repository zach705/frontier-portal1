
import * as React from "react";

export function Switch({ checked, onCheckedChange }: { checked: boolean; onCheckedChange: (v: boolean) => void; }) {
  return (
    <button
      onClick={() => onCheckedChange(!checked)}
      type="button"
      aria-pressed={checked}
      className={`inline-flex h-6 w-11 items-center rounded-full transition-colors ${checked ? "bg-slate-900" : "bg-slate-300"}`}
    >
      <span className={`h-5 w-5 bg-white rounded-full transition-transform transform ${checked ? "translate-x-5" : "translate-x-1"}`} />
    </button>
  );
}
